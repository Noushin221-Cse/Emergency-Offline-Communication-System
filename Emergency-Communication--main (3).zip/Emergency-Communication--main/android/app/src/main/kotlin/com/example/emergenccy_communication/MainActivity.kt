package com.example.emergenccy_communication

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
